/*
 * Arrow.h
 *
 */

#ifndef ARROW_H_
#define ARROW_H_

void getRightArrow(void);
void getLeftArrow(void);
void getUpArrow(void);
void getDownArrow(void);
void drawArrow(tU8 i);

#endif /* ARROW_H_ */
