/*
 * Reflexes.h
 *
 */

#ifndef REFLEXES_H_
#define REFLEXES_H_
void timer(void);
char* read(void);
tU8 rand(void);
char* getrand(void);

void initApp(void);
void authorsFooter(void);
void instructionsInfo(void);
void highScores(void);

#endif /* REFLEXES_H_ */
